package org.cap.dao;

import java.util.List;

import org.cap.model.Account;

public interface IAccountDao {
	
	public void createAccount(Account account);
	public List<Account> getAllAccounts(int customerId);
	

}

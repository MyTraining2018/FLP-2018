package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Transaction;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
@javax.transaction.Transactional
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext(type=PersistenceContextType.EXTENDED)
	private EntityManager entityManager;

	@Override
	public void createAccount(Account account) {
		
		Query query= entityManager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		//System.out.println(account);
		
		entityManager.persist(account);
		
	}

	@Override
	public List<Account> getAllAccounts(int customerId) {
		
		Query query= entityManager
			.createQuery("from Account acc where acc.customer.customerId=:custId");
		
		query.setParameter("custId", customerId);
		
		Query query2=entityManager
				.createQuery("from Transaction tx where tx.customer.customerId=:custId");
		
		query2.setParameter("custId", customerId);
		List<Account> accounts= query.getResultList();
		
		List<Transaction> transactions=query2.getResultList();
		
		
		
		
		return accounts;
	}

}

package org.cap.service;

import org.cap.model.Pilot;

public interface PilotService {
	public void save(Pilot pilot);
}

package org.cap.service;

import org.cap.dao.IAccountDao;
import org.cap.model.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("acccountService")
public class AccountServiceImpl implements IAccountService{

	@Autowired
	private IAccountDao accountDao;

	@Override
	public void createAccount(Account account) {
		
		accountDao.createAccount(account);
	}
}

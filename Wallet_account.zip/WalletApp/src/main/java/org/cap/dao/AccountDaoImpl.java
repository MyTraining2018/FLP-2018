package org.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.cap.model.Account;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("accountDao")
@Transactional
public class AccountDaoImpl implements IAccountDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void createAccount(Account account) {
		
		Query query= entityManager.createQuery("select max(accountNo) from Account");
		
		List<Long> max= query.getResultList();
		
		account.setAccountNo(max.get(0)+1);
		
		System.out.println(account);
		
		entityManager.persist(account);
		
	}

}

package org.cap.demo.controller;

import org.cap.demo.dao.ProductDao;
import org.cap.demo.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
public class UploadingController {
    public static final String uploadingdir = System.getProperty("user.dir") + "/src/main/resources/static/uploadingdir/";

    @Autowired
    private ProductDao productDao;
    
    
    @RequestMapping("/")
    public String uploading(Model model) {
        File file = new File(uploadingdir);
        model.addAttribute("files", file.listFiles());
        model.addAttribute("product", new Product());
        return "uploading";
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    public String uploadingPost(@RequestParam("uploadingFiles") MultipartFile uploadingFiles,
    		@ModelAttribute("product") Product product) throws IOException {
    	int imgName=0;
      //  for(MultipartFile uploadedFile : uploadingFiles) {
            File file = new File(uploadingdir + uploadingFiles.getOriginalFilename());
            uploadingFiles.transferTo(file);
            
          
            
            
            String path=file.getPath();
            
           String extenstion= path.substring(path.lastIndexOf('.'), path.length());
            
            //product.setImgUrl("../uploadingdir/" +imgName+".jpg");
            
            productDao.save(product);
            
            System.out.println(extenstion);
            Integer productId=productDao.findMaxProductId();
            if(productId!=null)
            	imgName=productId;
            else
            	imgName=0;
            File file2=new File(uploadingdir+imgName+ extenstion);
            file.renameTo(file2);
            
            
            product.setImgUrl("../uploadingdir/" +imgName+ extenstion);
            productDao.save(product);
        //}

        return "redirect:show";
    }
    
    
    @RequestMapping("/show")
    public String showProducts(Model model) {
    	
    	List<Product> products= productDao.findAll();
    	model.addAttribute("products", products);
    	return "show";
    }
}
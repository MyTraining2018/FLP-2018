package org.cap.demo;

import org.cap.demo.controller.UploadingController;
import org.springframework.boot.SpringApplication;
import java.io.File;
import java.io.IOException;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@SpringBootApplication
public class SpringBootImageApplication  {

	public static void main(String[] args)throws IOException {
		new File(UploadingController.uploadingdir).mkdirs();
		SpringApplication.run(SpringBootImageApplication.class, args);
	}
	
	
	
}
